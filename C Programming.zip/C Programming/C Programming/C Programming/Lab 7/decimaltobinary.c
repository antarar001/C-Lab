#include <stdio.h>
void decimalToBinary(int decimal, int binaryArray[], int *size) {
    int index = 0;
    while (decimal > 0) {
        binaryArray[index] = decimal % 2;
        decimal /= 2;
        index++;
    }
    *size = index;
}
int main() {
    int decimal,i;
    printf("Enter a decimal number: ");
    scanf("%d", &decimal);
    if (decimal < 0) {
        printf("Please enter a non-negative decimal number.\n");
        return 1;  
    }
    int binaryArray[32];  
    int size = 0;         
    decimalToBinary(decimal, binaryArray, &size);
    printf("Binary representation: ");
    for (i = size - 1; i >= 0; i--) {
        printf("%d", binaryArray[i]);
    }
    return 0;
}
