#include<stdio.h>
int main()
{
	int arr[100],max,min,i,n;
	printf("Enter the size of the array");
	scanf("%d",&n);
	printf("Enter the elements \n");
		for(i=0;i<n;i++)
		{
		scanf("%d",&arr[i]);
		}
		min = max = arr[0];
		for(i=1;i<n;i++)
		{
			if(max<arr[i])
			{
			max = arr[i];
			}
			if(min>arr[i])
			{
			min = arr[i];
		}
		}
	printf("Maximum of the number is %d\n",max);
	printf("Minimum of the number is %d",min);
	return 0;
}
