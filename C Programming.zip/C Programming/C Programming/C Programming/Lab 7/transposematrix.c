#include <stdio.h>
void transposeMatrix(int matrix[][10], int rows, int cols) {
    int transposedMatrix[10][10],i,j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            transposedMatrix[j][i] = matrix[i][j];
        }
    }
    for (i = 0; i < cols; i++) {
        for (j = 0; j < rows; j++) {
            matrix[i][j] = transposedMatrix[i][j];
        }
    }
}
void displayMatrix(int matrix[][10], int rows, int cols) {
	int i,j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int matrix[10][10];
    int rows, cols,i,j;

    // Get the number of rows and columns for the matrix
    printf("Enter the number of rows: ");
    scanf("%d", &rows);

    printf("Enter the number of columns: ");
    scanf("%d", &cols);

    // Check if the matrix is non-empty
    if (rows <= 0 || cols <= 0) {
        printf("Invalid matrix dimensions\n");
        return 1;  // Exit the program with an error code
    }

    // Input elements for the matrix
    printf("Enter elements for the matrix:\n");
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("Element [%d][%d]: ", i + 1, j + 1);
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("\nOriginal Matrix:\n");
    displayMatrix(matrix, rows, cols);

    // Call the transposeMatrix function to transpose the matrix
    transposeMatrix(matrix, rows, cols);

    printf("\nTransposed Matrix:\n");
    displayMatrix(matrix, cols, rows);

    return 0;
}
