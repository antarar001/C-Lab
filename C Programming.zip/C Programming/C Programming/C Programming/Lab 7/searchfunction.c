#include <stdio.h>
int searchElement(int arr[], int size, int element) {
	int i;
    for (i = 0; i < size; i++) {
        if (arr[i] == element) {
            return i; 
        }
    }
    return -1;
}

int main() {
    int size, element,i;
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    if (size <= 0) {
        printf("Invalid size\n");
        return 1;  
    }
    int arr[size];
    printf("Enter elements for the array:\n");
    for (i = 0; i < size; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
    printf("Enter the element to search: ");
    scanf("%d", &element);
    int index = searchElement(arr, size, element);
    if (index != -1) {
        printf("Element %d found at index %d\n", element, index);
    } else {
        printf("Element %d not found in the array\n", element);
    }
    return 0;
}
