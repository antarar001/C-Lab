#include <stdio.h>
void deleteElement(int arr[], int *size, int position) {
	int i;
    if (position < 0 || position >= *size) {
        printf("Invalid position\n");
        return;
    }
    for (i = position; i < *size - 1; i++) {
        arr[i] = arr[i + 1];
    }
    (*size)--;
}
int main() {
    int size, position,i;
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    if (size <= 0) {
        printf("Array is empty.\n");
        return 1;
    }
    int arr[size];
    printf("Enter elements for the array:\n");
    for (i = 0; i < size; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
    printf("Enter the position to delete: ");
    scanf("%d", &position);
    deleteElement(arr, &size, position);
    printf("Array after deletion:\n");
    for (i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    return 0;
}
