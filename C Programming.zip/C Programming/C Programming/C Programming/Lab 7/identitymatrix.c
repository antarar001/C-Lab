#include <stdio.h>
int isIdentityMatrix(int matrix[][10], int size) {
	int i,j;
    for (i = 0; i < size; i++) {
        if (matrix[i][i] != 1) {
            return 0; 
        }
        for (j = 0; j < size; j++) {
            if (i != j && matrix[i][j] != 0) {
                return 0; 
            }
        }
    }
    return 1; 
}
void displayMatrix(int matrix[][10], int rows, int cols) {
	int i,j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }
}
int main() {
    int matrix[10][10];
    int size;
    int i,j;
    printf("Enter the size of the square matrix: ");
    scanf("%d", &size);
    if (size <= 0) {
        printf("Invalid matrix size\n");
        return 1;
    }
    printf("Enter elements for the matrix:\n");
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            printf("Element [%d][%d]: ", i + 1, j + 1);
            scanf("%d", &matrix[i][j]);
        }
    }
    if (isIdentityMatrix(matrix, size)) {
        printf("\nThe given matrix is an Identity Matrix.\n");
    } else {
        printf("\nThe given matrix is not an Identity Matrix.\n");
    }
    printf("\nOriginal Matrix:\n");
    displayMatrix(matrix, size, size);
    return 0;
}
