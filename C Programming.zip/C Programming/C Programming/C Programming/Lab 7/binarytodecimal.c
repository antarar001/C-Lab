#include <stdio.h>
int binaryToDecimal(int binaryArray[], int size) {
    int decimal = 0;
    int base = 1,i;
    for (i = 0; i < size; i++) {
        decimal += binaryArray[i] * base;
        base *= 2;
    }
    return decimal;
}
int main() {
    int size,i;
    printf("Enter the size of the binary array: ");
    scanf("%d", &size);
    if (size <= 0) {
        printf("Invalid size\n");
        return 1; 
    }
    int binaryArray[size];
    printf("Enter binary digits (0 or 1) for the array:\n");
    for (i = 0; i < size; i++) {
        printf("Digit %d: ", i + 1);
        scanf("%d", &binaryArray[i]);
        if (binaryArray[i] != 0 && binaryArray[i] != 1) {
            printf("Invalid input. Please enter binary digits (0 or 1).\n");
            return 1; 
        }
    }
    int decimal = binaryToDecimal(binaryArray, size);
    printf("Decimal representation: %d\n", decimal);
    return 0;
}
