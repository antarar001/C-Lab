#include <stdio.h>
void multiplyMatrices(int firstMatrix[][10], int secondMatrix[][10], int resultMatrix[][10], int rows1, int cols1, int rows2, int cols2) {
	int i,j,k;
    if (cols1 != rows2) {
        printf("Matrices cannot be multiplied. Invalid dimensions.\n");
        return;
    }
    for (i = 0; i < rows1; i++) {
        for (j = 0; j < cols2; j++) {
            resultMatrix[i][j] = 0;
        }
    }
    for (i = 0; i < rows1; i++) {
        for (j = 0; j < cols2; j++) {
            for (k = 0; k < cols1; k++) {
                resultMatrix[i][j] += firstMatrix[i][k] * secondMatrix[k][j];
            }
        }
    }
}
void displayMatrix(int matrix[][10], int rows, int cols) {
	int i,j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }
}

int main() {
	int i,j;
    int firstMatrix[10][10], secondMatrix[10][10], resultMatrix[10][10];
    int rows1, cols1, rows2, cols2;
    printf("Enter the number of rows for the first matrix: ");
    scanf("%d", &rows1);
    printf("Enter the number of columns for the first matrix: ");
    scanf("%d", &cols1);
    printf("Enter the number of rows for the second matrix: ");
    scanf("%d", &rows2);
    printf("Enter the number of columns for the second matrix: ");
    scanf("%d", &cols2);
    if (cols1 != rows2) {
        printf("Matrices cannot be multiplied. Invalid dimensions.\n");
        return 1; 
    }
    printf("Enter elements for the first matrix:\n");
    for (i = 0; i < rows1; i++) {
        for (j = 0; j < cols1; j++) {
            printf("Element [%d][%d]: ", i + 1, j + 1);
            scanf("%d", &firstMatrix[i][j]);
        }
    }
    printf("Enter elements for the second matrix:\n");
    for (i = 0; i < rows2; i++) {
        for (j = 0; j < cols2; j++) {
            printf("Element [%d][%d]: ", i + 1, j + 1);
            scanf("%d", &secondMatrix[i][j]);
        }
    }
    multiplyMatrices(firstMatrix, secondMatrix, resultMatrix, rows1, cols1, rows2, cols2);
    printf("\nFirst Matrix:\n");
    displayMatrix(firstMatrix, rows1, cols1);
    printf("\nSecond Matrix:\n");
    displayMatrix(secondMatrix, rows2, cols2);
    printf("\nResult Matrix:\n");
    displayMatrix(resultMatrix, rows1, cols2);
    return 0;
}
