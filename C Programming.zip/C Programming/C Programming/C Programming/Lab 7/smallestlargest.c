#include <stdio.h>
void findSmallestAndLargest(int arr[], int size, int *smallest, int *largest) {
	int i;
    *smallest = *largest = arr[0];
    for (i = 1; i < size; i++) {
        if (arr[i] < *smallest) {
            *smallest = arr[i];
        } else if (arr[i] > *largest) {
            *largest = arr[i];
        }
    }
}
int main() {
    int size,i;
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    if (size <= 0) {
        printf("Invalid size\n");
        return 1; 
    }
    int arr[size];
    printf("Enter elements for the array:\n");
    for (i = 0; i < size; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
    int smallest, largest;
    findSmallestAndLargest(arr, size, &smallest, &largest);
    printf("Smallest element: %d\n", smallest);
    printf("Largest element: %d\n", largest);
    return 0;
}

