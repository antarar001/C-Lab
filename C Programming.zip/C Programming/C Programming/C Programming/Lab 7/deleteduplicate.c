#include <stdio.h>
int removeDuplicates(int arr[], int size) {
	int i;
    if (size <= 1) {
        return size;  
    }
    int uniqueIndex = 0;
    for (i = 1; i < size; i++) {
        int j;
        for (j = 0; j <= uniqueIndex; j++) {
            if (arr[i] == arr[j]) {
                break; 
            }
        }
        if (j == uniqueIndex + 1) {
            uniqueIndex++;
            arr[uniqueIndex] = arr[i];
        }
    }
    return uniqueIndex + 1;  
}
int main() {
    int size,i;
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    if (size <= 0) {
        printf("Invalid size\n");
        return 1; 
    }
    int arr[size];
    printf("Enter elements for the array:\n");
    for (i = 0; i < size; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
    int newSize = removeDuplicates(arr, size);
    printf("Array after removing duplicates:\n");
    for (i = 0; i < newSize; i++) {
        printf("%d ", arr[i]);
    }
    return 0;
}
