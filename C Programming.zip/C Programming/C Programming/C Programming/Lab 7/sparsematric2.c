#include <stdio.h>
int isSparseMatrix(int matrix[][10], int rows, int cols) {
    int countZeros = 0;
int i,j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            if (matrix[i][j] == 0) {
                countZeros++;
            }
        }
    }
    if (countZeros > (rows * cols) / 2) {
        return 1; 
    } else {
        return 0; 
}
}
void displayMatrix(int matrix[][10], int rows, int cols) {
	int i,j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }
}
int main() {
	int i,j;
    int matrix[10][10];
    int rows, cols;
    printf("Enter the number of rows: ");
    scanf("%d", &rows);
    printf("Enter the number of columns: ");
    scanf("%d", &cols);
    if (rows <= 0 || cols <= 0) {
        printf("Invalid matrix dimensions\n");
        return 1; 
    }
    printf("Enter elements for the matrix:\n");
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("Element [%d][%d]: ", i + 1, j + 1);
            scanf("%d", &matrix[i][j]);
        }
    }
    if (isSparseMatrix(matrix, rows, cols)) {
        printf("\nThe given matrix is a Sparse Matrix.\n");
    } else {
        printf("\nThe given matrix is not a Sparse Matrix.\n");
    }
    printf("\nOriginal Matrix:\n");
    displayMatrix(matrix, rows, cols);
    return 0;
}
