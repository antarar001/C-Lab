#include <stdio.h>
void insertElement(int arr[], int *size, int position, int element) {
	int i;
    if (position < 0 || position > *size) {
        printf("Invalid position\n");
        return;
    }
    for (i = *size; i > position; i--) {
        arr[i] = arr[i - 1];
    }
    arr[position] = element;
    (*size)++;
}

int main() {
    int size, position, element,i;
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    int arr[size];
    printf("Enter elements for the array:\n");
    for (i = 0; i < size; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
    printf("Enter the position to insert: ");
    scanf("%d", &position);
    printf("Enter the element to insert: ");
    scanf("%d", &element);
    insertElement(arr, &size, position, element);
    printf("Array after insertion:\n");
    for (i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    return 0;
}
