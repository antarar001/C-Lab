#include <stdio.h>
int main() {
    int n,i;
    printf("Enter the number of students: ");
    scanf("%d", &n);
    int mathMarks[n];
    int engMarks[n];
    for (i = 0; i < n; i++) {
        printf("Enter Mathematics marks for student %d: ", i + 1);
        scanf("%d", &mathMarks[i]);

        printf("Enter English marks for student %d: ", i + 1);
        scanf("%d", &engMarks[i]);
    }
    printf("\nTotal marks for each student:\n");
    for (i = 0; i < n; i++) {
        int totalMarks = mathMarks[i] + engMarks[i];
        printf("Student %d: %d\n", i + 1, totalMarks);
    }
    return 0;
}
