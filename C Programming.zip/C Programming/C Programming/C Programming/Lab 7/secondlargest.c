#include<stdio.h>
int main()
{
	int arr[100],max,max2,i,n;
	printf("Enter the size of the array");
	scanf("%d",&n);
	printf("Enter the elements \n");
		for(i=0;i<n;i++)
		{
		scanf("%d",&arr[i]);
		}
		max = max2 = arr[0];
		for(i=1;i<n;i++)
		{
		if(max<arr[i])
		{
		max2 = max;
		max = arr[i];
		}
		else if(arr[i] > max2 && arr[i] < max)
        {
            
            max2 = arr[i];
        }
    	}
		
	printf("Second largest no. of the array is %d\n",max2);
	return 0;
}
