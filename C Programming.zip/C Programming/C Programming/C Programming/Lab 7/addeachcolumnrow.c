#include <stdio.h>
void addElements(int matrix[][10], int rows, int cols) {
	int i,j;
    int rowSum[10] = {0};
    int colSum[10] = {0};
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            rowSum[i] += matrix[i][j];
        }
    }
    for (j = 0; j < cols; j++) {
        for (i = 0; i < rows; i++) {
            colSum[j] += matrix[i][j];
        }
    }
    printf("\nSum of each row:\n");
    for (i = 0; i < rows; i++) {
        printf("Row %d: %d\n", i + 1, rowSum[i]);
    }
    printf("\nSum of each column:\n");
    for (j = 0; j < cols; j++) {
        printf("Column %d: %d\n", j + 1, colSum[j]);
    }
}
void displayMatrix(int matrix[][10], int rows, int cols) {
	int i,j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }
}
int main() {
	int i,j;
    int matrix[10][10];
    int rows, cols;
    printf("Enter the number of rows: ");
    scanf("%d", &rows);
    printf("Enter the number of columns: ");
    scanf("%d", &cols);
    if (rows <= 0 || cols <= 0) {
        printf("Invalid matrix dimensions\n");
        return 1; 
    }
    printf("Enter elements for the matrix:\n");
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("Element [%d][%d]: ", i + 1, j + 1);
            scanf("%d", &matrix[i][j]);
        }
    }
    printf("\nOriginal Matrix:\n");
    displayMatrix(matrix, rows, cols);
    addElements(matrix, rows, cols);

    return 0;
}
