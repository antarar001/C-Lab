/*Write a C program to print the numbers from 1 to 10*/
#include<stdio.h>
int main()
{
	int i;
	printf("The numbers are: \n");
	for(i=1;i<=10;i++)
		{
			printf("%d \n",i);
		}
	return 0;
}
