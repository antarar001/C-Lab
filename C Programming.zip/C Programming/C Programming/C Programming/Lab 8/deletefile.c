#include <stdio.h>

int main() {
    char filename[100];

    // Get the filename from the user
    printf("Enter the filename to delete: ");
    scanf("%s", filename);

    // Attempt to delete the file
    if (remove(filename) == 0) {
        printf("File '%s' deleted successfully.\n", filename);
    } else {
        perror("Error deleting the file");
        return 1; // Exit with an error code
    }

    return 0;
}
