#include <stdio.h>

// Define a structure for distance
struct Distance {
    int feet;
    float inches;
};

// Function to add two distances
struct Distance addDistances(struct Distance d1, struct Distance d2) {
    struct Distance result;

    result.feet = d1.feet + d2.feet;
    result.inches = d1.inches + d2.inches;

    // If the sum of inches exceeds 12, convert it to feet
    if (result.inches >= 12.0) {
        result.inches -= 12.0;
        result.feet++;
    }

    return result;
}

int main() {
    // Declare variables for two distances
    struct Distance distance1, distance2, sum;

    // Read the first distance
    printf("Enter the first distance:\n");
    printf("Feet: ");
    scanf("%d", &distance1.feet);
    printf("Inches: ");
    scanf("%f", &distance1.inches);

    // Read the second distance
    printf("\nEnter the second distance:\n");
    printf("Feet: ");
    scanf("%d", &distance2.feet);
    printf("Inches: ");
    scanf("%f", &distance2.inches);

    // Add the distances
    sum = addDistances(distance1, distance2);

    // Display the result
    printf("\nSum of Distances: %d feet %.2f inches\n", sum.feet, sum.inches);

    return 0;
}
