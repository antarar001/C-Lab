#include <stdio.h>
#include <dirent.h>
#include <sys/types.h>

void listFilesAndDirectories(const char *path) {
    DIR *dir;
    struct dirent *entry;

    // Open the directory
    dir = opendir(path);

    // Check if the directory can be opened
    if (dir == NULL) {
        perror("Error opening directory");
        return;
    }

    // Read each entry in the directory
    while ((entry = readdir(dir)) != NULL) {
        // Ignore "." and ".." entries
        if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
            printf("%s\n", entry->d_name);
        }
    }

    // Close the directory
    closedir(dir);
}

int main() {
    const char *path = "D:\PassportPhoto.jpg";  // Replace "." with the path of the directory you want to list

    printf("Files and sub-directories in '%s':\n", path);
    listFilesAndDirectories(path);

    return 0;
}
