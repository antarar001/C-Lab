#include <stdio.h>

// Define a structure for employee details
struct Employee {
    int employeeId;
    char name[50];
    char designation[50];
    float salary;
};

int main() {
    // Declare a variable of type Employee
    struct Employee emp;

    // Read employee details
    printf("Enter Employee Details:\n");
    printf("Employee ID: ");
    scanf("%d", &emp.employeeId);

    printf("Name: ");
    scanf(" %[^\n]s", emp.name);

    printf("Designation: ");
    scanf(" %[^\n]s", emp.designation);

    printf("Salary: ");
    scanf("%f", &emp.salary);

    // Print employee details
    printf("\nEmployee Details:\n");
    printf("Employee ID: %d\n", emp.employeeId);
    printf("Name: %s\n", emp.name);
    printf("Designation: %s\n", emp.designation);
    printf("Salary: %.2f\n", emp.salary);

    return 0;
}
