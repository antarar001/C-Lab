#include <stdio.h>
#include <string.h>

int main() {
    char str1[100], str2[100], result[200];

    // Input the first string
    printf("Enter the first string: ");
    scanf("%s", str1);

    // Input the second string
    printf("Enter the second string: ");
    scanf("%s", str2);

    // Concatenate the two strings
    strcpy(result, str1);  // Copy the first string to the result
    strcat(result, str2);  // Concatenate the second string to the result

    // Display the concatenated string
    printf("Concatenated String: %s\n", result);

    return 0;
}
