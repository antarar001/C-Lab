#include <stdio.h>
#include <string.h>

int main() {
    int i;
	char str[100];

    // Input the string
    printf("Enter a string: ");
    scanf("%s", str);

    // Find the length of the string
    int length = strlen(str);

    // Print the reverse of the string
    printf("Reverse of the string: ");
    for (i = length - 1; i >= 0; i--) {
        printf("%c", str[i]);
    }

    printf("\n");

    return 0;
}
