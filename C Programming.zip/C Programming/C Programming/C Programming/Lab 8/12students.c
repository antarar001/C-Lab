#include <stdio.h>

// Define a structure for student details
struct student {
    int rollNo;
    char name[50];
    char address[100];
    int age;
    float averageMarks;
};

// Function to display student details
void displayStudentDetails(struct student s[], int n) {
    printf("\nStudent Details:\n");
    printf("| %-8s | %-20s | %-30s | %-4s | %-12s |\n", "Roll No", "Name", "Address", "Age", "Average Marks");
    printf("|----------|----------------------|----------------------------|------|--------------|\n");

    for (int i = 0; i < n; ++i) {
        printf("| %-8d | %-20s | %-30s | %-4d | %-12.2f |\n", s[i].rollNo, s[i].name, s[i].address, s[i].age, s[i].averageMarks);
    }
}

int main() {
    // Declare an array to store details of 12 students
    struct student students[12];

    // Read details for each student
    for (int i = 0; i < 12; ++i) {
        printf("Enter details for student %d:\n", i + 1);

        printf("Enter Roll No: ");
        scanf("%d", &students[i].rollNo);

        printf("Enter Name: ");
        scanf(" %[^\n]s", students[i].name);

        printf("Enter Address: ");
        scanf(" %[^\n]s", students[i].address);

        printf("Enter Age: ");
        scanf("%d", &students[i].age);

        printf("Enter Average Marks: ");
        scanf("%f", &students[i].averageMarks);
    }

    // Call the function to display student details
    displayStudentDetails(students, 12);

    return 0;
}
