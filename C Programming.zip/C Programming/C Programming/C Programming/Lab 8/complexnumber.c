#include <stdio.h>

// Define a structure for complex numbers
typedef struct {
    float real;
    float imag;
} complex;

// Function to add two complex numbers
complex add(complex num1, complex num2) {
    complex result;
    result.real = num1.real + num2.real;
    result.imag = num1.imag + num2.imag;
    return result;
}

// Function to subtract two complex numbers
complex subtract(complex num1, complex num2) {
    complex result;
    result.real = num1.real - num2.real;
    result.imag = num1.imag - num2.imag;
    return result;
}

int main() {
    // Declare variables for two complex numbers
    complex num1, num2, sum, difference;

    // Read the first complex number
    printf("Enter the real and imaginary parts of the first complex number: ");
    scanf("%f %f", &num1.real, &num1.imag);

    // Read the second complex number
    printf("Enter the real and imaginary parts of the second complex number: ");
    scanf("%f %f", &num2.real, &num2.imag);

    // Perform addition and subtraction
    sum = add(num1, num2);
    difference = subtract(num1, num2);

    // Display the results
    printf("\nSum: %.2f + %.2fi\n", sum.real, sum.imag);
    printf("Difference: %.2f + %.2fi\n", difference.real, difference.imag);

    return 0;
}
