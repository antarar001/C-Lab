#include <stdio.h>

int main() {
    FILE *file1, *file2, *mergedFile;
    char file1Name[100], file2Name[100], mergedFileName[100];
    char ch;

    // Get the first filename from the user
    printf("Enter the first filename: ");
    scanf("%s", file1Name);

    // Open the first file in read mode
    file1 = fopen(file1Name, "r");

    // Check if the first file exists
    if (file1 == NULL) {
        printf("Error opening the first file.\n");
        return 1; // Exit with an error code
    }

    // Get the second filename from the user
    printf("Enter the second filename: ");
    scanf("%s", file2Name);

    // Open the second file in read mode
    file2 = fopen(file2Name, "r");

    // Check if the second file exists
    if (file2 == NULL) {
        printf("Error opening the second file.\n");
        fclose(file1); // Close the first file before exiting
        return 1; // Exit with an error code
    }

    // Get the merged filename from the user
    printf("Enter the merged filename: ");
    scanf("%s", mergedFileName);

    // Open the merged file in write mode
    mergedFile = fopen(mergedFileName, "w");

    // Check if the merged file is opened successfully
    if (mergedFile == NULL) {
        printf("Error opening the merged file.\n");
        fclose(file1); // Close the first file before exiting
        fclose(file2); // Close the second file before exiting
        return 1; // Exit with an error code
    }

    // Copy the contents from the first file to the merged file
    while ((ch = fgetc(file1)) != EOF) {
        fputc(ch, mergedFile);
    }

    // Copy the contents from the second file to the merged file
    while ((ch = fgetc(file2)) != EOF) {
        fputc(ch, mergedFile);
    }

    // Close all files
    fclose(file1);
    fclose(file2);
    fclose(mergedFile);

    printf("Files merged successfully.\n");

    return 0;
}
