#include <stdio.h>
int main() {
    int N, sum = 0,i;
    printf("Enter the value of N: ");
    scanf("%d", &N);
    printf("The first %d odd numbers are:\n", N);
    for (i = 1; i <= 2 * N; i += 2) {
        printf("%d ", i);
        sum += i;
    }
    printf("\nThe sum of the first %d odd numbers is: %d\n", N, sum);
    return 0;
}
