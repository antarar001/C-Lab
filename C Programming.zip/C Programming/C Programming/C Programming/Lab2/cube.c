#include <stdio.h>

// Function to calculate the cube of a number
int cube(int num) {
    return num * num * num;
}

int main() {
    int N;

    // Input N
    printf("Enter the value of N: ");
    scanf("%d", &N);

    // Display the cube of numbers from 1 to N
    printf("Cube of numbers from 1 to %d are:\n", N);
    
    for (int i = 1; i <= N; i++) {
        printf("%d^3 = %d\n", i, cube(i));
    }

    return 0;
}
