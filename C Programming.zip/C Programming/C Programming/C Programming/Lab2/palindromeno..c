#include <stdio.h>
int main() {
	int m,n,d,s=0;
	printf("Enter a number");
	scanf("%d",&n);
	m=n;
	while(n!=0)
	{
		d = n % 10;
		s = s * 10 + d;
		n = n / 10;
	}
	if(m==s)
	{
		printf("Palindrome no.");
	}
	else
	{
		printf("Not a palindrome no.");
	}
	return 0;
}
