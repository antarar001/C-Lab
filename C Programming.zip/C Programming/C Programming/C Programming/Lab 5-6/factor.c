#include<stdio.h>
int main()
{
	int n,i;
	printf("Enter a number ");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		if(n%i==0)
		{
			printf("%d is a factor\n",i);
		}
	}
	return 0;
}
