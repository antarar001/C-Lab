#include <stdio.h>

    int main()
    {
    	int a,b;
        printf("Enter two integers\n");
        scanf("%d %d",&a,&b);
        int c = a + b;
        printf("Addition = %d",c);
        return 0;
    }
    
