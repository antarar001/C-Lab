#include <stdio.h>

// Function to find the first digit of a number
int findFirstDigit(int num) {
    while (num >= 10) {
        num /= 10;
    }
    return num;
}

// Function to find the last digit of a number
int findLastDigit(int num) {
    return num % 10;
}

int main() {
    int number;

    // Input the number
    printf("Enter a number: ");
    scanf("%d", &number);

    // Find and print the first and last digits
    printf("First digit: %d\n", findFirstDigit(number));
    printf("Last digit: %d\n", findLastDigit(number));

    return 0;
}
